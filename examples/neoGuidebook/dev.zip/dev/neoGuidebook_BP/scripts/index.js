import { registerCustomBlockComponent, registerCustomItemComponent } from "./custom_components/registry";


registerCustomBlockComponent();
registerCustomItemComponent();